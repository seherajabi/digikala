


INSERT INTO User (first_name, last_name,   email,                        is_confirmed, birth_date,     career,              phone_number,  national_number)
VALUES (          'Neda',     'Karimi',    'neda.karimi@example.com',    1,            '1985-07-12',   'Architect',         '09123456789', '1234567891'),
       (          'Amir',     'Hosseini',  'amir.hosseini@example.com',  0,            '1990-05-23',   'Journalist',        '09129876543', '9876543210'),
       (          'Zahra',    'Mousavi',   'zahra.mousavi@example.com',  1,            '1988-11-30',   'Graphic Designer',  '09121234567', '1230984567'),
       (          'Behnam',   'Rahmani',   'behnam.rahmani@example.com', 0,            '1992-03-15',   'Software Engineer', '09122334455', '7654321980'),
       (          'Sara',     'Ghasemi',   'sara.ghasemi@example.com',   1,            '1984-09-09',   'Doctor',            '0912001122',  '1122334455');


INSERT INTO Discount (discount_code, discount_amount)
              VALUES ('DISCOUNT100', 100),
                     ('SAVE50',      50),
                     ('OFFER20',     20),
                     ('PROMO30',     30),
                     ('DEAL15',      15);


INSERT INTO Cart (user_id, discount_id)
          VALUES (1,       NULL), -- کاربر 1، بدون تخفیف
                 (2,       1), -- کاربر 2، با تخفیف id 1
                 (3,       NULL), -- کاربر 3، بدون تخفیف
                 (4,       2), -- کاربر 4، با تخفیف id 2
                 (5,       NULL); -- کاربر 5، بدون تخفیف


INSERT INTO List (title,           description,                      user_id)
          VALUES ('Shopping List', 'List of groceries to buy',       1),
                 ('Work Tasks',    'Tasks to complete for work',     2),
                 ('Books to Read', 'My reading list for this month', 3),
                 ('Travel Plan',   'Itinerary for upcoming trip',    4),
                 ('Fitness Goals', 'Exercise and diet plan',         5);


INSERT INTO Payment_card (card_number,        bank,     user_id)
                  VALUES ('1234567890123456', 'Bank A', 1),
                         ('2345678901234567', 'Bank B', 2),
                         ('1475665451234987', 'Bank C', 2),
                         ('3456789012345678', 'Bank C', 3),
                         ('4567890123456789', 'Bank D', 4),
                         ('5678901234567890', 'Bank E', 5);



INSERT INTO Address (province,     city,      postal_code, user_id)
             VALUES ('Tehran',     'Tehran',  '123456',    1),
                    ('Isfahan',    'Isfahan', '234567',    2),
                    ('Mazandaran', 'Sari',    '345678',    3),
                    ('Mazandaran', 'babol',   '569858',    3),
                    ('Fars',       'Shiraz',  '456789',    4),
                    ('Khorasan',   'Mashhad', '567890',    5),
                    ('Khorasan',   'ghoochan','846415',    5);



INSERT INTO Warranty_provider (name)
                       VALUES ('Warranty Co. A'),
                              ('Guarantee Group B'),
                              ('Secure Warranty Services C'),
                              ('Reliable Warranty Corp D'),
                              ('Trustworthy Guarantee E');

INSERT INTO Provider (name)
              VALUES ('Provider Alpha'),
                     ('Beta Services'),
                     ('Gamma Solutions'),
                     ('Delta Corp'),
                     ('Epsilon Enterprises');



INSERT INTO Product (title,       cost, introduction,                inventory_amount, discount, star, warranty_period, warranty_provider_id, provider_id)
             VALUES ('Product A', 1000, 'Introduction of Product A', 50,               10,       4,    12,              1,                    1),
                    ('Product B', 1500, 'Introduction of Product B', 30,               5,        3,    6,               2,                    2),
                    ('Product C', 2000, 'Introduction of Product C', 20,               15,       5,    18,              1,                    3),
                    ('Product D', 2500, 'Introduction of Product D', 40,               0,        4,    24,              2,                    4),
                    ('Product E', 3000, 'Introduction of Product E', 10,               20,       5,    12,              1,                    5);




INSERT INTO Product_img (img,                         product_id)
                 VALUES ('/images/productA_img1.jpg', 1),
                        ('/images/productA_img2.jpg', 1),
                        ('/images/productB_img1.jpg', 2),
                        ('/images/productC_img1.jpg', 3),
                        ('/images/productD_img1.jpg', 4);


INSERT INTO Review (title, text, star, anonymous, user_id, product_id) VALUES ('Great Product', 'I really liked this product. Highly recommend!', 5, 0, 1, 1);
INSERT INTO Review (title, text, star, anonymous, user_id, product_id) VALUES ('Good, but...', 'The product is good, but it has some issues.', 3, 0, 2, 1);
INSERT INTO Review (title, text, star, anonymous, user_id, product_id) VALUES ('Not Satisfied', 'I expected more from this product.', 2, 1, 3, 2);
INSERT INTO Review (title, text, star, anonymous, user_id, product_id) VALUES ('Excellent!', 'This is exactly what I needed!', 5, 0, 4, 3);
INSERT INTO Review (title, text, star, anonymous, user_id, product_id) VALUES ('Decent Product', 'Overall its a decent product for the price.', 4, 1, 5, 3);



INSERT INTO Review_img (img, review_id) VALUES ('/images/review1_img1.jpg', 1);
INSERT INTO Review_img (img, review_id) VALUES ('/images/review1_img2.jpg', 1);
INSERT INTO Review_img (img, review_id) VALUES ('/images/review2_img1.jpg', 2);
INSERT INTO Review_img (img, review_id) VALUES ('/images/review3_img1.jpg', 3);
INSERT INTO Review_img (img, review_id) VALUES ('/images/review4_img1.jpg', 4);



INSERT INTO Category (title, parent_id) VALUES ('Electronics', NULL); -- دسته اصلی
INSERT INTO Category (title, parent_id) VALUES ('Computers', 1); -- زیرمجموعه Electronics
INSERT INTO Category (title, parent_id) VALUES ('Smartphones', 1); -- زیرمجموعه Electronics
INSERT INTO Category (title, parent_id) VALUES ('Fashion', NULL); -- دسته اصلی
INSERT INTO Category (title, parent_id) VALUES ('Men\s Clothing', 4); -- زیرمجموعه Fashion


INSERT INTO Attribute (title, category_id) VALUES ('Color', 1); -- ویژگی برای دسته‌بندی Electronics
INSERT INTO Attribute (title, category_id) VALUES ('CPU', 2); -- ویژگی برای دسته‌بندی Computers
INSERT INTO Attribute (title, category_id) VALUES ('Memory', 2); -- ویژگی برای دسته‌بندی Computers
INSERT INTO Attribute (title, category_id) VALUES ('Size', 4); -- ویژگی برای دسته‌بندی Fashion
INSERT INTO Attribute (title, category_id) VALUES ('Fabric', 5); -- ویژگی برای دسته‌بندی Men's Clothing


INSERT INTO Sub_attribute (title, attribute_id) VALUES ('Red', 1); -- زیر ویژگی برای ویژگی 'Color'
INSERT INTO Sub_attribute (title, attribute_id) VALUES ('Blue', 1); -- زیر ویژگی برای ویژگی 'Color'
INSERT INTO Sub_attribute (title, attribute_id) VALUES ('Intel Core i7', 2); -- زیر ویژگی برای ویژگی 'CPU'
INSERT INTO Sub_attribute (title, attribute_id) VALUES ('16GB', 3); -- زیر ویژگی برای ویژگی 'Memory'
INSERT INTO Sub_attribute (title, attribute_id) VALUES ('Cotton', 5); -- زیر ویژگی برای ویژگی 'Fabric'


INSERT INTO Payment (issue_tracking, payment_card_id) VALUES ('no issue', 1);
INSERT INTO Payment (issue_tracking, payment_card_id) VALUES ('no issue', 2);
INSERT INTO Payment (issue_tracking, payment_card_id) VALUES ('pending confirmation', 3);
INSERT INTO Payment (issue_tracking, payment_card_id) VALUES ('no issue', 4);
INSERT INTO Payment (issue_tracking, payment_card_id) VALUES ('issue reported', 5);


INSERT INTO _Order (total_cost, status, user_id, address_id, payment_card_id, payment_id) VALUES (1000, 'pending', 1, 1, 1, 1);
INSERT INTO _Order (total_cost, status, user_id, address_id, payment_card_id, payment_id) VALUES (1500, 'sent', 2, 2, 2, 2);
INSERT INTO _Order (total_cost, status, user_id, address_id, payment_card_id, payment_id) VALUES (2000, 'pending', 3, 3, 3, 3);
INSERT INTO _Order (total_cost, status, user_id, address_id, payment_card_id, payment_id) VALUES (2500, 'completed', 4, 4, 4, 4);
INSERT INTO _Order (total_cost, status, user_id, address_id, payment_card_id, payment_id) VALUES (3000, 'pending', 5, 5, 5, 5);



INSERT INTO Cart_Product_join_table (cart_id, product_id) VALUES (1, 1);
INSERT INTO Cart_Product_join_table (cart_id, product_id) VALUES (1, 2);
INSERT INTO Cart_Product_join_table (cart_id, product_id) VALUES (2, 3);
INSERT INTO Cart_Product_join_table (cart_id, product_id) VALUES (2, 4);
INSERT INTO Cart_Product_join_table (cart_id, product_id) VALUES (3, 5);



INSERT INTO Product_Sub_attribute_join_table (product_id, sub_attribute_id) VALUES (1, 1);
INSERT INTO Product_Sub_attribute_join_table (product_id, sub_attribute_id) VALUES (2, 2);
INSERT INTO Product_Sub_attribute_join_table (product_id, sub_attribute_id) VALUES (3, 3);
INSERT INTO Product_Sub_attribute_join_table (product_id, sub_attribute_id) VALUES (1, 4);
INSERT INTO Product_Sub_attribute_join_table (product_id, sub_attribute_id) VALUES (2, 5);


INSERT INTO Product_Category_join_table (product_id, category_id) VALUES (1, 1);
INSERT INTO Product_Category_join_table (product_id, category_id) VALUES (2, 2);
INSERT INTO Product_Category_join_table (product_id, category_id) VALUES (3, 3);
INSERT INTO Product_Category_join_table (product_id, category_id) VALUES (1, 4);
INSERT INTO Product_Category_join_table (product_id, category_id) VALUES (2, 5);








