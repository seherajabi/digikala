-- this script will build up the entire database

-- the user table
create table User(
    --each table will have an id column as it's primary key
    id integer primary key autoincrement ,
    first_name text not null ,
    last_name text not null ,
    email text not null ,
    is_confirmed integer not null default 0 ,
    birth_date text not null ,
    career text not null ,
    phone_number text not null ,
    national_number text not null
);

--discounts protocols are defined here
create table Discount(
    id integer primary key autoincrement ,
    discount_code text not null unique , --the code should be unique
    -- we will not have repeated codes here.
    discount_amount integer not null
);


--this is the cart table, each user
--will have a cart
create table Cart(
    id integer primary key autoincrement ,
    user_id integer not null unique , --each cart have
    -- a unique user
    discount_id integer,--each cart can have a discount protocol
    foreign key (user_id) references User(id),
    foreign key (discount_id) references Cart(id)
);


-- each user han have different lists
-- like the lists of what he likes
-- or the lists of possible future buys
create table List(
    id integer primary key autoincrement ,
    title text not null ,--the title of the list
    description text ,-- a simple description of the list
    user_id integer,-- the user that the list belongs to
    foreign key (user_id) references User(id)
);


--users payment cards are defined here
--each user can have many different payment cards
create table Payment_card(
    id integer primary key autoincrement ,
    card_number text not null ,--number of the card
    bank text not null ,--name of the bank
    user_id integer ,--the user that the card belongs to
    foreign key (user_id) references User(id)
);


--addresses
--each user can have multiple addresses
create table Address(
    id integer primary key autoincrement ,
    province text not null ,--the province of the address
    city text not null ,--the actual city
    postal_code text not null unique ,--the postal code that should be unique
    user_id integer,--the user that a address belongs to
    foreign key (user_id) references User(id)
);

--warranty providers
--the data of the companies that
--are providing or warranties
create table Warranty_provider(
    id integer primary key autoincrement ,
    name text not null
);

--provider
--the companies that are providing or products
create table Provider(
    id integer primary key autoincrement ,
    name text not null
);


--the products
create table Product(
    id integer primary key autoincrement ,
    title text not null ,
    --the name of the product
    cost integer not null default 0,
    --the actual cost of the product
    introduction text ,
    --several paragraphs that introduces the product
    inventory_amount integer not null default 0,
    --the amount of this product at the inventory
    --can not be null and the default value is 0
    discount integer not null default 0,
    --maybe this product has a special discount
    --discount should be represented as percentage
    --and the default discount is zero
    star integer not null default 0,
    --how many star this product has?
    --should be between 0 and 5
    warranty_period integer not null default 0,
    --how many months this product has warranty?
    warranty_provider_id integer,
    --the company that provides or warranties
    provider_id integer,
    --the company that is providing this product
    foreign key (provider_id) references Provider(id),
    foreign key (warranty_provider_id) references Warranty_provider(id)
);


--the images of our products are stored here
create table Product_img(
    id integer primary key autoincrement ,
    img text not null ,
    --will be the address of the img file on our system
    product_id integer ,
    foreign key (product_id) references Product(id) on delete cascade on update cascade
);


--reviews of each product should be
--in this table
create table Review(
    id integer primary key autoincrement ,
    title text not null ,
    text text not null ,
    --the actual text of the comment
    star integer not null default 0,
    --how many stars does this review have?
    --by default it's zero, it can increase up to 5 stars
    anonymous integer not null default 0,
    --zero means this review should be published
    --publicly and one means the other way
    --it can only be zero and one
    user_id integer ,
    product_id integer ,
    foreign key (user_id) references User(id) on delete cascade on update cascade ,
    foreign key (product_id) references Product(id) on delete cascade on update cascade
);

--each review can have
--some images, we can store them here
create table Review_img(
    id integer primary key autoincrement ,
    img text not null ,
    --the address of the img on our server
    review_id integer ,
    --the review that this img belongs to
    foreign key (review_id) references Review(id) on delete cascade on update cascade
);


--categories
--each category can have several
--categories inside itself
--forming a parent and child relationship
create table Category(
    id integer primary key autoincrement ,
    title text not null ,
    parent_id integer ,
    foreign key (parent_id) references Category(id) on delete cascade on update cascade
);

--attributes
--each attributes like color, shape, size and etc are stored here
create table Attribute(
    id integer primary key autoincrement ,
    title text not null ,
    --like color, shape, cpus, memory ...
    category_id integer,
    --the category that this attribute belongs to
    foreign key (category_id) references Category(id) on delete cascade on update cascade
);

--sub-attributes
--each attribute can have several sub attributes
--like the attribute color can have several sub attributes
--for example red, green, blue...
--our the attribute cpu can have sub attributes like
--core-i7, core-i5 and ...
create table Sub_attribute(
    id integer primary key autoincrement ,
    title text not null ,
    --the actual name of the sub attribute
    attribute_id integer,
    --the attribute that this sub attribute belongs to
    foreign key (attribute_id) references Attribute(id) on delete cascade on update cascade
);


--payment
--is the information about each transactions
create table Payment(
    id integer primary key autoincrement ,
    issue_tracking text not null default 'no issue',
    payment_card_id integer ,
    --the card that did this payment
    foreign key (payment_card_id) references Payment_card(id) on delete cascade on update cascade
);



--order
--an order is a set of products that are going to be sent to the user
--the underline before it's name is for not conflicting with
--sql reserved key_wards
create table _Order(
    id integer primary key autoincrement ,
    total_cost integer not null ,
    --the actual cost of this order
    status text not null default 'pending',
    --the status of the order
    --whether it is sent or it is pending or it is in the history
    user_id integer,
    --the user that this order belongs to
    address_id integer,
    --the address in which this order should be send to
    payment_card_id integer,
    --the information about the payment card that this order use
    payment_id integer,
    --there is a one to one relationship between the payment table and the order table
    foreign key (user_id) references User(id) on delete cascade on update cascade ,
    foreign key (address_id) references Address(id) on delete cascade on update cascade ,
    foreign key (payment_card_id) references Payment_card(id) on delete cascade on update cascade ,
    foreign key (payment_id) references Payment(id) on delete cascade on update cascade
);



--next we will create the join tables
--joins tables are for many to many relationships


--there is a many to many relationship
--between cart and product
--it means that each product can be in several carts
--and each cart can have several product in it
create table Cart_Product_join_table(
    id integer primary key autoincrement ,
    cart_id integer,
    product_id integer,
    foreign key (cart_id) references Cart(id) on delete cascade on update cascade ,
    foreign key (product_id) references Product(id) on delete cascade on update cascade
);

--each product can have several sub attributes
--and each sub attribute can belong to several products
create table Product_Sub_attribute_join_table(
    id integer primary key autoincrement ,
    product_id integer,
    sub_attribute_id integer,
    foreign key (product_id) references Product(id) on delete cascade on update cascade ,
    foreign key (sub_attribute_id) references Sub_attribute(id) on delete cascade on update cascade
);


--each product can belong to several categories
--each category can have several products in it
create table Product_Category_join_table(
    id integer primary key autoincrement ,
    product_id integer,
    category_id integer,
    foreign key (product_id) references Product(id) on delete cascade on update cascade ,
    foreign key (category_id) references Category(id) on delete cascade on update cascade
);


