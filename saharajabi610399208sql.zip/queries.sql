-- 1. دریافت تمامی محصولات
SELECT * FROM Product;

-- 2. جستجوی کاربران بر اساس ایمیل
SELECT * FROM User WHERE email = 'example@example.com';

-- 3. لیست سفارشات یک کاربر خاص
SELECT * FROM _Order WHERE user_id = 1;

-- 4. جستجوی محصولات با تخفیف
SELECT * FROM Product WHERE discount > 0;

-- 5. دریافت اطلاعات کارت‌های پرداخت یک کاربر
SELECT * FROM Payment_card WHERE user_id = 1;

-- 6. نمایش دسته‌بندی‌های فرزند یک دسته‌بندی خاص
SELECT * FROM Category WHERE parent_id = 1;

-- 7. لیست بررسی‌ها و امتیازات محصول خاص
SELECT title, text, star FROM Review WHERE product_id = 1;

-- 8. جستجوی محصولات بر اساس ویژگی خاص
SELECT Product.* FROM Product
JOIN Product_Sub_attribute_join_table ON Product.id = Product_Sub_attribute_join_table.product_id
WHERE sub_attribute_id = 1;

-- 9. دریافت تعداد محصولات در هر دسته‌بندی
SELECT Category.title, COUNT(Product.id) AS ProductCount FROM Category
JOIN Product_Category_join_table ON Category.id = Product_Category_join_table.category_id
JOIN Product ON Product.id = Product_Category_join_table.product_id
GROUP BY Category.id;

-- 10. لیست کل سفارشات و مجموع هزینه‌ها
SELECT _Order.id, SUM(total_cost) AS TotalCost FROM _Order
GROUP BY _Order.id;
-- 1. لیست کاربران و تعداد سفارشات آن‌ها
SELECT User.id, User.first_name, User.last_name, COUNT(_Order.id) AS OrderCount
FROM User
LEFT JOIN _Order ON User.id = _Order.user_id
GROUP BY User.id;

-- 2. محصولاتی که بیشترین تخفیف را دارند
SELECT * FROM Product
WHERE discount = (SELECT MAX(discount) FROM Product);

-- 3. محصولاتی که هیچ بررسی ندارند
SELECT Product.id, Product.title
FROM Product
LEFT JOIN Review ON Product.id = Review.product_id
WHERE Review.id IS NULL;

-- 4. میانگین امتیاز هر دسته‌بندی از محصولات
SELECT Category.title, AVG(Review.star) AS AvgStar
FROM Category
JOIN Product_Category_join_table ON Category.id = Product_Category_join_table.category_id
JOIN Product ON Product_Category_join_table.product_id = Product.id
JOIN Review ON Product.id = Review.product_id
GROUP BY Category.id;

-- 5. کاربرانی که بیش از یک آدرس دارند
SELECT User.id, User.first_name, User.last_name, COUNT(Address.id) AS AddressCount
FROM User
JOIN Address ON User.id = Address.user_id
GROUP BY User.id
HAVING COUNT(Address.id) > 1;

-- 6. محصولات با بیشترین تعداد بررسی
SELECT Product.id, Product.title, COUNT(Review.id) AS ReviewCount
FROM Product
JOIN Review ON Product.id = Review.product_id
GROUP BY Product.id
ORDER BY ReviewCount DESC
LIMIT 5;

-- 7. تعداد محصولات در هر زیر ویژگی
SELECT Sub_attribute.title, COUNT(Product_Sub_attribute_join_table.product_id) AS ProductCount
FROM Sub_attribute
JOIN Product_Sub_attribute_join_table ON Sub_attribute.id = Product_Sub_attribute_join_table.sub_attribute_id
GROUP BY Sub_attribute.id;

-- 8. مجموع هزینه سفارشات برای هر کاربر
SELECT User.id, User.first_name, User.last_name, SUM(_Order.total_cost) AS TotalSpent
FROM User
JOIN _Order ON User.id = _Order.user_id
GROUP BY User.id;

-- 9. محصولاتی که در همه دسته‌بندی‌ها موجود هستند
SELECT Product.id, Product.title
FROM Product
WHERE NOT EXISTS (
  SELECT * FROM Category
  WHERE NOT EXISTS (
    SELECT * FROM Product_Category_join_table
    WHERE Product_Category_join_table.product_id = Product.id
    AND Product_Category_join_table.category_id = Category.id
  )
);

-- 10. جستجوی پیچیده: کاربرانی که سفارشاتی با بیش از یک محصول دارند
SELECT User.id, User.first_name, User.last_name
FROM User
JOIN _Order ON User.id = _Order.user_id
JOIN Cart_Product_join_table ON _Order.id = Cart_Product_join_table.cart_id
GROUP BY User.id
HAVING COUNT(DISTINCT Cart_Product_join_table.product_id) > 1;
